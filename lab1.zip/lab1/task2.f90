
program task2
    use iso_fortran_env, only: int64, real64
    implicit none

    integer(int64), parameter :: trials = 1000000_int64

    integer(int64) :: experiment
    integer(int64) :: count_B, count_AB
    integer :: dice1, dice2, total
    real :: u1, u2
    real(real64) :: p_estimate, p_theory

    call random_seed()

    count_B = 0_int64
    count_AB = 0_int64

    do experiment = 1_int64, trials

        call random_number(u1)
        call random_number(u2)

        dice1 = 1 + int(6 * u1)
        dice2 = 1 + int(6 * u2)

        total = dice1 + dice2

        if (mod(total, 2) == 0) then
            count_B = count_B + 1_int64

            if (total == 8) then
                count_AB = count_AB + 1_int64
            end if
        end if

    end do

    p_estimate = real(count_AB, real64) / real(count_B, real64)
    p_theory = 5.0_real64 / 18.0_real64

    print *, "Number of trials =", trials
    print *, "B probability =", count_B
    print *, "A and B probability =", count_AB
    print *, "Experimental probability =", p_estimate
    print *, "Theoretical probability =", p_theory

end program task2
