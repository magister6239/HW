
program task3
    use iso_fortran_env, only: int64, real64
    implicit none

    integer, parameter :: deck_size = 36
    integer, parameter :: ace_count = 4
    integer(int64), parameter :: trials = 1000000_int64

    integer :: deck(deck_size)
    integer :: i

    integer(int64) :: experiment
    integer(int64) :: count_A, count_B, count_AB

    real(real64) :: p_A, p_A_given_B, p_AB, p_A_theory, p_A_given_B_theory, p_AB_theory

    call random_seed()

    do i = 1, deck_size
        deck(i) = i
    end do

    count_A = 0_int64
    count_B = 0_int64
    count_AB = 0_int64

    do experiment = 1_int64, trials

        call shuffle_deck(deck)

        if (deck(2) <= ace_count) then
            count_A = count_A + 1_int64
        end if

        if (deck(1) <= ace_count) then
            count_B = count_B + 1_int64

            if (deck(2) <= ace_count) then
                count_AB = count_AB + 1_int64
            end if
        end if

    end do

    p_A = real(count_A, real64) / real(trials, real64)

    p_A_given_B = real(count_AB, real64) / &
                  real(count_B, real64)

    p_AB = real(count_AB, real64) / real(trials, real64)

    p_A_theory = real(ace_count, real64) / &
                 real(deck_size, real64)

    p_A_given_B_theory = real(ace_count - 1, real64) / &
                         real(deck_size - 1, real64)

    p_AB_theory = p_A_theory * p_A_given_B_theory

    print *, "Number of trials =", trials
    print *, "First card was an ace =", count_B
    print *, "Second card was an ace =", count_A
    print *, "Both cards were aces =", count_AB

    print *, "P(A), experimental =", p_A
    print *, "P(A), theoretical  =", p_A_theory

    print *, "P(A|B), experimental =", p_A_given_B
    print *, "P(A|B), theoretical  =", p_A_given_B_theory

    print *, "P(A and B), experimental =", p_AB
    print *, "P(A and B), theoretical  =", p_AB_theory

contains

    subroutine shuffle_deck(deck)
        implicit none

        integer, intent(inout) :: deck(:)
        integer :: i, j, temp
        real :: u

        do i = size(deck), 2, -1
            call random_number(u)
            j = 1 + int(i * u)

            temp = deck(i)
            deck(i) = deck(j)
            deck(j) = temp
        end do

    end subroutine shuffle_deck

end program task3
