
program task1
    use iso_fortran_env, only: int8, int64, real64
    implicit none

    integer(int64), parameter :: n = 100_int64
    integer(int64), parameter :: trials = 1000000_int64

    integer(int8), allocatable :: q(:)
    integer(int64) :: experiment, good_count, balance
    integer :: i
    integer(int8) :: temp
    integer :: j
    real :: u
    real(real64) :: p_estimate, p_theory
    logical :: good

    allocate(q(2*n))

    do i = 1, size(q)/2
        q(i) = 1_int8
        q(i + size(q)/2) = -1_int8
    end do

    call random_seed()

    good_count = 0_int64

    do experiment = 1_int64, trials

        do i = size(q), 2, -1
            call random_number(u)
            j = 1 + int(i*u)

            temp = q(i)
            q(i) = q(j)
            q(j) = temp
        end do

        balance = 0_int64

        do i = 1, size(q)
            balance = balance + int(q(i), int64)

            if (balance > 0_int64) then
                good_count = good_count + 1_int64
                exit
            end if
        end do

    end do

    p_estimate = real(good_count, real64) / real(trials, real64)
    p_theory = 1.0_real64 / (real(n, real64) + 1.0_real64)

    print *, "n =", n
    print *, "Trials =", trials
    print *, "Good outcomes =", good_count
    print *, "Experimental probability =", p_estimate
    print *, "Theoretical probability =", p_theory

end program task1
